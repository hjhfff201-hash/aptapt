import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from basicsr.utils.registry import ARCH_REGISTRY


def discriminator_block(in_filters, out_filters, normalization=False):
    """Returns downsampling layers of each discriminator block"""
    layers = [nn.Conv2d(in_filters, out_filters, 3, stride=2, padding=1)]
    layers.append(nn.LeakyReLU(0.2))
    if normalization:
        layers.append(nn.InstanceNorm2d(out_filters, affine=True))
        #layers.append(nn.BatchNorm2d(out_filters))

    return layers


def generator_block(in_filters, out_filters, normalization=False):
    """Returns downsampling layers of each discriminator block"""
    layers = [nn.Conv2d(in_filters, out_filters, 3, stride=1, padding=1)]
    layers.append(nn.LeakyReLU(0.2))
    if normalization:
        layers.append(nn.InstanceNorm2d(out_filters, affine=True))
        #layers.append(nn.BatchNorm2d(out_filters))
    return layers


class Classifier(nn.Module):
    def __init__(self, output_dim=3):
        super(Classifier, self).__init__()

        self.model = nn.Sequential(
            nn.Upsample(size=(256,256),mode='bilinear'), #将图像调整为(256,256)
            nn.Conv2d(3, 16, 3, stride=2, padding=1),
            nn.LeakyReLU(0.2),
            nn.InstanceNorm2d(16, affine=True),
            *discriminator_block(16, 32, normalization=True),
            *discriminator_block(32, 64, normalization=True),
            *discriminator_block(64, 128, normalization=True),
            *discriminator_block(128, 128),
            # *discriminator_block(128, 128, normalization=True),
            nn.Dropout(p=0.5),
            nn.Conv2d(128, output_dim, 8, padding=0),
        )

    def forward(self, img_input):
        return self.model(img_input)
    

class Contextor(nn.Module):
    def __init__(self, in_channels=3):
        super(Contextor, self).__init__()

        self.input_layer = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, stride=1, padding=1),
            nn.LeakyReLU(0.2),  # 加入非线性，让特征“活起来” 普通 ReLU：负数直接变 0 → 神经元 “死了” 不再更新
            nn.InstanceNorm2d(16, affine=True), #归一化通过把特征分布标准化到均值为 0、方差为 1,缓解梯度消失与梯度爆炸问题，稳定网络参数更新过程
        )

        self.mid_layer = nn.Sequential(
            *generator_block(16, 16, normalization=True),
            *generator_block(16, 16, normalization=True),
            *generator_block(16, 16, normalization=True),
        )

        self.output_layer = nn.Sequential(
            nn.Dropout(p=0.5),  #训练时随机关掉部分神经元，不让模型死记训练集，
            nn.Conv2d(16, 1, 3, stride=1, padding=1),
            nn.Sigmoid()
        )


    def forward(self, img_input):
        x = self.input_layer(img_input)
        identity = x
        out = self.mid_layer(x)
        out += identity
        out = self.output_layer(out)
        return out


class Generator3DLUT_identity(nn.Module):
    def __init__(self, dim=33):
        super(Generator3DLUT_identity, self).__init__()
        if dim == 33:
            file = open("/root/autodl-tmp/unsuperviesed/data/IdentityLUT33.txt",'r')
        elif dim == 64:
            file = open("/root/autodl-tmp/unsuperviesed/data/IdentityLUT64.txt",'r')
        LUT = file.readlines()   #从 txt 读出来的字符串列表（临时变量） 
        self.LUT = torch.zeros(3,dim,dim,dim, dtype=torch.float)

        for i in range(0,dim):
            for j in range(0,dim):
                for k in range(0,dim):
                    n = i * dim*dim + j * dim + k
                    x = LUT[n].split()   #LUT[n] = "0.031250  0.000000  0.000000\n"为单个字符串 .split() 默认是按“任意空白字符”切分
                                         #切开后为["0.031250", "0.000000", "0.000000"]
                    self.LUT[0,i,j,k] = float(x[0])   #用float(x[0])将字符串转换为真正的数值
                    self.LUT[1,i,j,k] = float(x[1])
                    self.LUT[2,i,j,k] = float(x[2])
        self.LUT = nn.Parameter(self.LUT)
        self.TrilinearInterpolation = TrilinearInterpolation()

    def forward(self, x):

        return self.TrilinearInterpolation(self.LUT, x)
    


class Generator3DLUT_zero(nn.Module):
    def __init__(self, dim=33):
        super(Generator3DLUT_zero, self).__init__()

        self.LUT = torch.zeros(3,dim,dim,dim, dtype=torch.float)
        self.LUT = nn.Parameter(self.LUT)
        self.TrilinearInterpolation = TrilinearInterpolation()

    def forward(self, x):

        return self.TrilinearInterpolation(self.LUT, x)





class TrilinearInterpolation(nn.Module):
    def __init__(self):
        super(TrilinearInterpolation, self).__init__()


    def forward(self, LUT, img):
        b = img.shape[0]
        # scale im between -1 and 1 since its used as grid input in grid_sample
        #这一步是为了把图像的 RGB 值转换成 grid_sample 所需的 [-1,1] 坐标，从而在 3D LUT 中正确采样。
        img = (img - 0.5) * 2.  # [0, 1]  映射为   [-1, 1] 

        # grid_sample expects NxDxHxWx3 (1x1xHxWx3)
        # 这行代码把图像从通道格式转换为 grid_sample 所需的三维坐标格式，使每个像素的 RGB 成为 LUT 查询坐标。
        img = img.permute(0, 2, 3, 1)[:, None]   #[b,3,h,w] -[b,h,w,3]- [b,1,,h,w,3] [:, None]=unsqueeze(1)

        # add batch dim to LUT
        LUT = torch.tile(LUT[None], dims=(b, 1, 1, 1, 1)) #LUT[None] : [3,dim,dim,dim]-[1,3,dim,dim,dim]
                                                    #tile(LUT[None], dims=(b, 1, 1, 1, 1)):[1,3,dim,dim,dim]- [b,3,dim,dim,dim]

        # grid sample
        result = F.grid_sample(LUT, img, mode='bilinear', padding_mode='border', align_corners=True)

        # drop added dimensions
        result = result[:, :, 0]

        return result


@ARCH_REGISTRY.register()
class LUTNet(nn.Module):
    def __init__(self, num_luts=3):
        """
        Args:
            num_luts: LUT的数量，默认为3
        """
        super(LUTNet, self).__init__()
        self.num_luts = num_luts

        self.gen_context = Contextor()
        # 分类器输出维度与LUT数量一致 # C,R,G,B w1+C,R,G + w2+C,R,B + w3*C,G,B + w4*R,G,B
        self.gen_bias = Classifier(output_dim=num_luts*4)

        # 创建LUT列表
        self.luts = nn.ModuleList()
        self.luts.append(Generator3DLUT_identity(dim=33))  # 第一个为identity LUT
        self.luts.append(Generator3DLUT_identity(dim=33))  # 第一个为identity LUT
        self.luts.append(Generator3DLUT_identity(dim=33))  # 第一个为identity LUT
        self.luts.append(Generator3DLUT_identity(dim=33))  # 第一个为identity LUT

        # 添加剩余的zero LUT
        for i in range(1, num_luts):
            self.luts.append(Generator3DLUT_zero(dim=33))
            self.luts.append(Generator3DLUT_zero(dim=33))
            self.luts.append(Generator3DLUT_zero(dim=33))
            self.luts.append(Generator3DLUT_zero(dim=33))


    def forward(self, img):
        """
        Args:
            img: 输入图像，形状为(b, c, h, w)
        Returns:
            out: 加权融合后的输出
            weights: 权重张量
            luts: 所有LUT的元组
        """

        context = self.gen_context(img)
        # 生成权重，形状为(b, num_luts, 1, 1)
        weights = self.gen_bias(img)
        context_rg = torch.cat((context, img[:, 0:1], img[:, 1:2]), dim=1)
        context_rb = torch.cat((context, img[:, 0:1], img[:, 2:3]), dim=1)
        context_bg = torch.cat((context, img[:, 1:2], img[:, 2:3]), dim=1)

        # 应用每个LUT并收集结果
        lut_outputs = []
        for i in range(self.num_luts):
            gen_rgb = self.luts[i*4](img)
            gen_crg = self.luts[i*4+1](context_rg)
            gen_crb = self.luts[i*4+2](context_rb)
            gen_cbg = self.luts[i*4+3](context_bg)

            lut_outputs.append(gen_rgb)
            lut_outputs.append(gen_crg)
            lut_outputs.append(gen_crb)
            lut_outputs.append(gen_cbg)

        # 加权融合
        out = torch.zeros_like(lut_outputs[0])
        for i in range(self.num_luts):
            out += lut_outputs[i*4] * weights[:, 4*i:4*i+1, :, :]
            out += lut_outputs[i*4+1] * weights[:, 4*i+1:4*i+2, :, :]
            out += lut_outputs[i*4+2] * weights[:, 4*i+2:4*i+3, :, :]
            out += lut_outputs[i*4+3] * weights[:, 4*i+3:4*i+4, :, :]

        return out, weights, tuple(self.luts)
    



if __name__ == '__main__':
    from thop import profile

    # 加载预训练模型
    model = LUTNet()
    model.eval()

    # 定义输入张量，尺寸需与模型输入匹配
    input_tensor = torch.randn(1, 3, 256, 256)

    # 使用 thop 计算 FLOPs 和参数量
    flops, params = profile(model, inputs=(input_tensor,))
  

    print('FLOPs = ' + str(flops/1000**3) + 'G')
    print('Params = ' + str(params/1000**2) + 'M')