import numpy as np
import os.path as osp
import torch
import cv2
from basicsr.archs import build_network
from basicsr.losses import build_loss
from basicsr.losses.gan_loss import r1_penalty
from basicsr.metrics import calculate_metric
from basicsr.models.base_model import BaseModel
from basicsr.utils import get_root_logger, imwrite, tensor2img
from basicsr.utils.registry import MODEL_REGISTRY
from collections import OrderedDict
from tqdm import tqdm


@MODEL_REGISTRY.register()
class LUTModel(BaseModel):

    def __init__(self, opt):
        super(LUTModel, self).__init__(opt)
        self.idx = 0  # it is used for saving data for check

        # define network
        self.net_g = build_network(opt['network_g'])
        self.net_g = self.model_to_device(self.net_g)
        self.print_network(self.net_g)

        # define network

        # load pretrained model
        load_path = self.opt['path'].get('pretrain_network_g', None)
        if load_path is not None:
            param_key = self.opt['path'].get('param_key_g', 'params')
            self.load_network(self.net_g, load_path, self.opt['path'].get('strict_load_g', True), param_key)


        if self.is_train:
            self.init_training_settings()


    def init_training_settings(self):
        train_opt = self.opt['train']

        self.ema_decay = train_opt.get('ema_decay', 0)
        # ----------- define net_g with Exponential Moving Average (EMA) ----------- #
        # net_g_ema only used for testing on one GPU and saving. There is no need to wrap with DistributedDataParallel
        if self.ema_decay > 0:
            self.net_g_ema = build_network(self.opt['network_g']).to(self.device)
            # load pretrained model
            load_path = self.opt['path'].get('pretrain_network_g', None)
            if load_path is not None:
                self.load_network(self.net_g_ema, load_path, self.opt['path'].get('strict_load_g', True), 'params_ema')
            else:
                self.model_ema(0)  # copy net_g weight
            self.net_g_ema.eval()


        self.net_g.train()

        # ----------- define losses ----------- #

        if train_opt.get('pixel_opt'):
            self.cri_pixel = build_loss(train_opt['pixel_opt']).to(self.device)
        else:
            self.cri_pixel = None

        if train_opt.get('perceptual_opt'):
            self.cri_perceptual = build_loss(train_opt['perceptual_opt']).to(self.device)
        else:
            self.cri_perceptual = None

        if train_opt.get('norm_opt'):
            self.cri_norm = build_loss(train_opt['norm_opt']).to(self.device)
        else:
            self.cri_norm = None

        if train_opt.get('tv3d_opt'):
            self.cri_tv3d = build_loss(train_opt['tv3d_opt']).to(self.device)
        else:
            self.cri_tv3d = None
        # set up optimizers and schedulers
        self.setup_optimizers()
        self.setup_schedulers()

    def setup_optimizers(self):
        train_opt = self.opt['train']

        # ----------- optimizer g ----------- #
        optim_type = train_opt['optim_g'].pop('type')


        self.optimizer_g = self.get_optimizer(optim_type, self.net_g.parameters(), **train_opt['optim_g'])

        self.optimizers.append(self.optimizer_g)


        # ----------- optimizer d ----------- #



    def feed_data(self, data):
        self.lq = data['lq'].to(self.device)
        self.hq = data['hq'].to(self.device)


    def optimize_parameters(self, current_iter):
        self.optimizer_g.zero_grad()

        loss_dict = OrderedDict()
        l_g_total = 0

        pred, weights, lut_list = self.net_g(self.lq)


        pixel_loss = self.cri_pixel(pred, self.hq)
        l_g_total += pixel_loss
        loss_dict['l_g_pixel'] = pixel_loss


        l_g_percep, l_g_style = self.cri_perceptual(pred, self.hq)
        if l_g_percep is not None:
            l_g_total += l_g_percep
            loss_dict['l_g_percep'] = l_g_percep
        if l_g_style is not None:
            l_g_total += l_g_style
            loss_dict['l_g_style'] = l_g_style

        weights_norm = self.cri_norm(weights)
        l_g_total += weights_norm
        loss_dict['l_g_norm'] = weights_norm

        tv_loss, mn_loss = self.cri_tv3d(lut_list)
        l_g_total += tv_loss
        loss_dict['l_g_tv'] = tv_loss
        l_g_total += mn_loss
        loss_dict['l_g_mn'] = mn_loss

        l_g_total.backward()

        self.optimizer_g.step()


        self.log_dict = self.reduce_loss_dict(loss_dict)
        # EMA
        if self.ema_decay > 0:
            self.model_ema(decay=self.ema_decay)

    def test(self):
        window_size = 16
        mod_pad_h, mod_pad_w = 0, 0
        _, _, h, w = self.lq.size()
        if h % window_size != 0:
            mod_pad_h = window_size - h % window_size
        if w % window_size != 0:
            mod_pad_w = window_size - w % window_size
        img = torch.nn.functional.pad(self.lq, (mod_pad_w//2, mod_pad_w-mod_pad_w//2, mod_pad_h//2, mod_pad_h-mod_pad_h//2), 'reflect')

        with torch.no_grad():
            if hasattr(self, 'net_g_ema'):
                self.net_g_ema.eval()
                output = self.net_g_ema(img)[0]
                _, _, h, w = output.size()
                self.output = output[:, :, mod_pad_h//2:h - mod_pad_h + mod_pad_h//2, mod_pad_w//2:w - mod_pad_w + mod_pad_w//2]

            else:
                logger = get_root_logger()
                logger.warning('Do not have self.net_g_ema, use self.net_g.')
                self.net_g.eval()
                output = self.net_g(img)[0]
                _, _, h, w = output.size()
                self.output = output[:, :, mod_pad_h//2:h - mod_pad_h + mod_pad_h//2, mod_pad_w//2:w - mod_pad_w + mod_pad_w//2]
                self.net_g.train()

        # gt_mean = self.gt.mean()
        # output_mean = self.output.mean()
        # self.output = self.output * gt_mean / output_mean

    def dist_validation(self, dataloader, current_iter, tb_logger, save_img):
        if self.opt['rank'] == 0:
            self.nondist_validation(dataloader, current_iter, tb_logger, save_img)


    def nondist_validation(self, dataloader, current_iter, tb_logger, save_img):
        dataset_name = dataloader.dataset.opt['name']
        with_metrics = self.opt['val'].get('metrics') is not None
        use_pbar = self.opt['val'].get('pbar', False)

        if with_metrics:
            if not hasattr(self, 'metric_results'):  # only execute in the first run
                self.metric_results = {metric: 0 for metric in self.opt['val']['metrics'].keys()}
            # initialize the best metric results for each dataset_name (supporting multiple validation datasets)
            self._initialize_best_metric_results(dataset_name)
            # zero self.metric_results
            self.metric_results = {metric: 0 for metric in self.metric_results}


        if use_pbar:
            pbar = tqdm(total=len(dataloader), unit='image')

        for idx, val_data in enumerate(dataloader):
            img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]
            self.feed_data(val_data)
            self.test()

            sr_img = tensor2img(self.output.detach().cpu())

            # tentative for out of GPU memory
            del self.lq
            del self.output
            torch.cuda.empty_cache()

            if save_img:
                if self.opt['val']['suffix']:
                    save_img_path = osp.join(self.opt['path']['visualization'], str(current_iter),
                                                f'{img_name}_{self.opt["val"]["suffix"]}.png')
                else:
                    save_img_path = osp.join(self.opt['path']['visualization'], str(current_iter),
                                                f'{img_name}_{self.opt["name"]}.png')
                imwrite(sr_img, save_img_path)

            # img_dir = osp.basename(osp.dirname(val_data['lq_path'][0]))
            # img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]
            # self.feed_data(val_data)
            # self.test()

            # sr_img = tensor2img(self.output.detach().cpu())


            # # tentative for out of GPU memory
            # del self.lq
            # del self.output
            # torch.cuda.empty_cache()

            # if save_img:
            #     if self.opt['val']['suffix']:
            #         save_img_path = osp.join(self.opt['path']['visualization'], str(current_iter), img_dir,
            #                                     f'{img_name}_{self.opt["val"]["suffix"]}.png')
            #     else:
            #         save_img_path = osp.join(self.opt['path']['visualization'], str(current_iter), img_dir,
            #                                     f'{img_name}_{self.opt["name"]}.png')

            #     imwrite(sr_img, save_img_path)
            if with_metrics:
                metric_data = dict()
                metric_data['img'] = sr_img
                if hasattr(self, 'hq'):
                    gt_img = tensor2img(self.hq.detach().cpu())
                    metric_data['img2'] = gt_img
                # calculate metrics
                for name, opt_ in self.opt['val']['metrics'].items():
                    self.metric_results[name] += calculate_metric(metric_data, opt_)
            if use_pbar:
                pbar.update(1)
                pbar.set_description(f'Test {img_name}')
        if use_pbar:
            pbar.close()

        if with_metrics:
            for metric in self.metric_results.keys():
                self.metric_results[metric] /= (idx + 1)
                # update the best metric result
                self._update_best_metric_result(dataset_name, metric, self.metric_results[metric], current_iter)

            self._log_validation_metric_values(current_iter, dataset_name, tb_logger)


    def _log_validation_metric_values(self, current_iter, dataset_name, tb_logger):
        log_str = f'Validation {dataset_name}\n'
        for metric, value in self.metric_results.items():
            log_str += f'\t # {metric}: {value:.4f}'
            if hasattr(self, 'best_metric_results'):
                log_str += (f'\tBest: {self.best_metric_results[dataset_name][metric]["val"]:.4f} @ '
                            f'{self.best_metric_results[dataset_name][metric]["iter"]} iter')
            log_str += '\n'

        logger = get_root_logger()
        logger.info(log_str)
        if tb_logger:
            for metric, value in self.metric_results.items():
                tb_logger.add_scalar(f'metrics/{dataset_name}/{metric}', value, current_iter)

    def save(self, epoch, current_iter):
        # save net_g and net_d
        if self.ema_decay > 0:
            self.save_network([self.net_g, self.net_g_ema], 'net_g', current_iter, param_key=['params', 'params_ema'])
        else:
            self.save_network([self.net_g], 'net_g', current_iter, param_key=['params'])


        # save training state
        self.save_training_state(epoch, current_iter)


    def save_best(self):
        # save net_g and net_d
        if self.ema_decay > 0:
            self.save_network([self.net_g, self.net_g_ema], 'net_g', 'best', param_key=['params', 'params_ema'])
        else:
            self.save_network([self.net_g], 'net_g', 'best', param_key=['params'])