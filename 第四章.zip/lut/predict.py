import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
# from archs.zerodce_imporve_arch import ImprovedUnsupervisedNet
from archs.lut_arch import LUTNet
from basicsr.utils import tensor2img, img2tensor, scandir, imwrite
from tqdm import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F


if __name__ == '__main__':
    model = LUTNet()
    model.load_state_dict(torch.load('/root/autodl-tmp/unsuperviesed/experiments/train_LUT/models/net_g_100000.pth')['params'])
    model.cuda()
    model.eval()

    root = '/root/autodl-tmp/datasets'


    img_names = list(scandir(root, recursive=True))

    for img_name in tqdm(img_names):
        if 'SICE' in img_name:
            continue
        if 'LSRW' in img_name and 'high' in img_name:
            continue
        if 'Train' in img_name:
            continue
        if 'Test' in img_name and 'Normal' in img_name:
            continue

        lq = cv2.imread(os.path.join(root, img_name)).astype(np.float32) / 255.0

        lq = img2tensor(lq, True, True).cuda()[None]

        img_name = os.path.splitext(img_name)[0]


        window_size = 16
        mod_pad_h, mod_pad_w = 0, 0
        _, _, h, w = lq.size()
        if h % window_size != 0:
            mod_pad_h = window_size - h % window_size
        if w % window_size != 0:
            mod_pad_w = window_size - w % window_size
        lq = torch.nn.functional.pad(lq, (mod_pad_w//2, mod_pad_w-mod_pad_w//2, mod_pad_h//2, mod_pad_h-mod_pad_h//2), 'reflect')

        try:
            with torch.no_grad():
                res = model(lq)[0]
        except RuntimeError as error:
            print('Error', error)



        res = res[:, :, mod_pad_h//2:mod_pad_h//2 + h, mod_pad_w//2:mod_pad_w//2 + w]

        assert res.shape[2] == h and res.shape[3] == w

        res = tensor2img(res)

        imwrite(res, os.path.join('results', img_name+'_lut.jpg'))