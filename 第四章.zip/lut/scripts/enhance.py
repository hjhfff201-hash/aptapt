import argparse
import cv2
import os
import numpy as np
from basicsr.utils import scandir, imwrite
from tqdm import tqdm


def intelligent_brightness_adjustment(image, target_brightness=0.6, max_adjustment=0.3):
    """
    智能亮度调整，将整体亮度控制在目标值附近
    target_brightness: 目标亮度 (0-1)
    max_adjustment: 最大调整幅度，防止过度调整
    """
    # 转换为灰度图计算当前亮度
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    current_brightness = np.mean(gray) / 255.0

    # 计算亮度差异，限制调整幅度
    brightness_diff = target_brightness - current_brightness
    adjusted_diff = np.clip(brightness_diff, -max_adjustment, max_adjustment)

    # 分析图像亮度分布，避免过曝和过暗
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])

    # 计算过曝和过暗像素比例
    overexposed_ratio = np.sum(hist[240:]) / np.sum(hist)  # 亮度>240的像素
    underexposed_ratio = np.sum(hist[:15]) / np.sum(hist)  # 亮度<15的像素

    # 根据过曝/过暗情况调整增益
    if overexposed_ratio > 0.05:  # 如果过曝像素超过5%
        gain = 0.5  # 大幅降低提亮强度
    elif overexposed_ratio > 0.02:  # 如果过曝像素超过2%
        gain = 0.8  # 适度降低提亮强度
    elif underexposed_ratio > 0.1:  # 如果过暗像素超过10%
        gain = 1.2  # 增强提亮效果
    else:
        gain = 1.0

    # 应用调整，使用伽马校正实现非线性亮度调整
    adjusted_diff = adjusted_diff * gain

    if adjusted_diff > 0:
        # 提亮：使用伽马校正避免过曝
        gamma = 1.0 - adjusted_diff * 0.5  # 0.85-1.0范围
        gamma_corrected = np.power(image / 255.0, gamma) * 255.0
        result = np.clip(gamma_corrected, 0, 255).astype(np.uint8)
    else:
        # 压暗：使用线性调整
        alpha = 1.0 + adjusted_diff
        result = cv2.convertScaleAbs(image, alpha=alpha, beta=0)

    return result


def adaptive_contrast_enhancement(image, clip_limit=2.0, grid_size=(8, 8)):
    """
    使用自适应直方图均衡化增强对比度
    clip_limit: 对比度限制阈值，防止过度增强
    grid_size: 网格大小，控制局部增强的粒度
    """
    # 转换为LAB色彩空间，只对亮度通道进行增强
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    # 创建CLAHE对象（限制对比度的自适应直方图均衡化）
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
    l_enhanced = clahe.apply(l)

    # 合并通道
    lab_enhanced = cv2.merge([l_enhanced, a, b])
    enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)
    return enhanced

def soft_saturation_enhancement(image, saturation_factor=1.3, gamma=0.8):
    """
    柔和的饱和度增强，避免过度饱和
    saturation_factor: 饱和度增强因子 (1.1-1.5)
    gamma: 伽马校正参数，控制增强的平滑度
    """
    # 转换为HSV色彩空间
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32)

    # 对饱和度通道进行伽马校正，实现平滑增强
    saturation = hsv[:, :, 1] / 255.0  # 归一化到[0,1]
    saturation = np.power(saturation, gamma)  # 伽马校正
    saturation = saturation * saturation_factor * 255.0  # 增强并恢复范围

    # 限制在有效范围内
    hsv[:, :, 1] = np.clip(saturation, 0, 255)

    # 转换回BGR
    enhanced = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
    return enhanced


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=int, default=0)
    args = parser.parse_args()
    src_root = '/root/autodl-tmp/datasets/SICE/PSEUDO_resize'
    dst_root = '/root/autodl-tmp/datasets/SICE/PSEUDO_resize_enhance'
    img_paths = sorted(list(scandir(src_root, recursive=True, full_path=False)))

    num_device = 1
    img_nums = len(img_paths) + num_device
    img_paths = img_paths[img_nums//num_device*args.device:img_nums//num_device*(args.device+1)]


    for img_path in tqdm(img_paths):

        img_name = os.path.splitext(img_path)[0]
        img_gt = cv2.imread(os.path.join(src_root, img_path))
        img_enhance_gt = intelligent_brightness_adjustment(img_gt)
        img_enhance_gt = adaptive_contrast_enhancement(img_enhance_gt)
        img_enhance_gt = soft_saturation_enhancement(img_enhance_gt)
        img_enhance_gt = img_enhance_gt * 0.5 + img_gt * 0.5
        imwrite(img_enhance_gt, os.path.join(dst_root, img_name+'.png'))