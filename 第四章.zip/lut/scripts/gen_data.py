import numpy as np
import cv2
import os
from basicsr.utils import scandir, imwrite
from tqdm import tqdm
import argparse
import torch


def opencv_mertens_fusion(images):
    """使用OpenCV的Mertens融合算法"""
    # 创建Mertens融合器
    merge_mertens = cv2.createMergeMertens()

    # 执行融合
    fused_image = merge_mertens.process(images)

    # 转换回8位无符号整数
    fused_image = np.clip(fused_image * 255, 0, 255).astype(np.uint8)


    return fused_image

# 5. demo
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=int, default=0)

    args = parser.parse_args()
    lq_dir = '/root/autodl-tmp/datasets/SICE/LQ'
    output_dir = '/root/autodl-tmp/datasets/SICE/PSEUDO'

    image_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}

    # 遍历lq下的两个主目录
    for main_dir in (os.listdir(lq_dir)):
        main_path = os.path.join(lq_dir, main_dir)
        if not os.path.isdir(main_path):
            continue

        sub_folders = os.listdir(main_path)
        folder_nums = len(sub_folders)
        num_device = 1
        folder_nums += num_device
        sub_folders = sub_folders[folder_nums//num_device*args.device:folder_nums//num_device*(args.device+1)]
        # 遍历主目录下的所有子文件夹
        for sub_folder in tqdm(sub_folders):
            sub_path = os.path.join(main_path, sub_folder)
            if not os.path.isdir(sub_path):
                continue

            # 读取子文件夹中的所有图像
            images = []
            for filename in os.listdir(sub_path):
                ext = os.path.splitext(filename)[1].lower()
                if ext in image_exts:
                    img_path = os.path.join(sub_path, filename)
                    img = cv2.imread(img_path)
                    if img is not None:
                        images.append(img)

            if images:
                # 平均融合
                blended = opencv_mertens_fusion(np.array([img.astype(np.float32)  for img in images]))

                # 创建输出目录并保存
                output_path = os.path.join(output_dir, main_dir, sub_folder)
                os.makedirs(output_path, exist_ok=True)
                cv2.imwrite(os.path.join(output_path, "blended.png"), blended)