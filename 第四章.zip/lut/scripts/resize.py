import argparse
import cv2
import os
import numpy as np
from basicsr.utils import scandir, imwrite
from tqdm import tqdm


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=int, default=0)
    args = parser.parse_args()
    # src_root = '/root/autodl-tmp/datasets/SICE/LQ'
    # dst_root = '/root/autodl-tmp/datasets/SICE/LQ_resize'
    src_root = '/root/autodl-tmp/datasets/SICE/PSEUDO'
    dst_root = '/root/autodl-tmp/datasets/SICE/PSEUDO_resize'
    img_paths = sorted(list(scandir(src_root, recursive=True, full_path=False)))

    num_device = 1
    img_nums = len(img_paths) + num_device
    img_paths = img_paths[img_nums//num_device*args.device:img_nums//num_device*(args.device+1)]

    for img_path in tqdm(img_paths):
        img_name = os.path.splitext(img_path)[0]
        img = cv2.imread(os.path.join(src_root, img_path))
        img_resize = cv2.resize(img, (512, 512))
        imwrite(img_resize, os.path.join(dst_root, img_name+'.png'))