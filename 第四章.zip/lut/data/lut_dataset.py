import cv2
import math
import numpy as np
import os
import random
import torch
from basicsr.data.data_util import paths_from_folder
from basicsr.data import degradations
from basicsr.data.transforms import augment
from basicsr.utils import FileClient, imfrombytes, img2tensor, scandir
from basicsr.utils.registry import DATASET_REGISTRY
from torch.utils import data as data
from torchvision.transforms.functional import (adjust_brightness, adjust_contrast, adjust_hue, adjust_saturation, normalize)



@DATASET_REGISTRY.register()
class LUTDataset(data.Dataset):
    def __init__(self, opt):
        super(LUTDataset, self).__init__()
        self.opt = opt
        self.file_client = None
        self.io_backend_opt = opt['io_backend']
        self.lq_folder = opt['dataroot_lq']
        self.hq_folder = opt['dataroot_hq']

        self.mean = opt['mean'] if 'mean' in opt else None
        self.std = opt['std'] if 'std' in opt else None


        self.scale = opt['scale'] if 'scale' in opt else 1
        self.gt_size = opt['gt_size'] if 'gt_size' in opt else 0


        self.mapping = self.get_lq_hq_mapping(self.lq_folder, self.hq_folder)

        # file client (lmdb io backend)
        if self.io_backend_opt['type'] == 'lmdb':
            pass
        else:
            self.raw_lq_paths = sorted([path for path in scandir(self.lq_folder, full_path=True, recursive=True)])
            # KeyError: '/root/autodl-tmp/datasets/SICE/LQ_resize/Dataset_Part1/1/.ipynb_checkpoints/1-checkpoint.png'
            self.lq_paths = []
            for raw_lq_path in self.raw_lq_paths:
                if '.ipynb_checkpoints' in raw_lq_path:
                    continue
                self.lq_paths.append(raw_lq_path)



    def get_lq_hq_mapping(self, lq_dir, output_dir):
        """生成lq到hq的映射字典"""
        image_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
        mapping = {}

        for main_dir in os.listdir(lq_dir):
            main_path = os.path.join(lq_dir, main_dir)
            if not os.path.isdir(main_path):
                continue

            for sub_folder in os.listdir(main_path):
                sub_path = os.path.join(main_path, sub_folder)
                if not os.path.isdir(sub_path):
                    continue

                # 确定hq图像路径
                hq_path = os.path.join(output_dir, main_dir, sub_folder, "blended.png")

                # 为每个lq图像创建映射
                for filename in os.listdir(sub_path):
                    ext = os.path.splitext(filename)[1].lower()
                    if ext in image_exts:
                        lq_path = os.path.join(sub_path, filename)
                        mapping[lq_path] = hq_path

        return mapping

    def __getitem__(self, index):
        if self.file_client is None:
            self.file_client = FileClient(self.io_backend_opt.pop('type'), **self.io_backend_opt)

        # -------------------------------- Load gt images -------------------------------- #
        lq_path = self.lq_paths[index]
        img_bytes = self.file_client.get(lq_path)
        img_lq = imfrombytes(img_bytes, float32=True)

        hq_path = self.mapping[lq_path]
        img_bytes = self.file_client.get(hq_path)
        img_hq = imfrombytes(img_bytes, float32=True)

        if self.opt['phase'] == 'train':
            # img_hq, img_lq = self.padding(img_hq, img_lq, self.gt_size)
            # img_hq, img_lq = self.random_crop(img_hq, img_lq, (self.gt_size, self.gt_size))

            gamma = random.uniform(0.7, 1.3)
            img_lq = img_lq ** gamma

            # -------------------- Do augmentation for training: flip, rotation -------------------- #
            # img_hq, img_lq = self.random_augmentation(img_hq, img_lq)



        img_hq, img_lq = img2tensor([img_hq, img_lq], bgr2rgb=True, float32=True)

        # round and clip
        img_lq = torch.clamp((img_lq * 255.0).round(), 0, 255) / 255.
        img_hq = torch.clamp((img_hq * 255.0).round(), 0, 255) / 255.
        # img_lq_noise = torch.clamp((img_lq_noise * 255.0).round(), 0, 255) / 255.

        # normalize
        if self.mean and self.std:
            normalize(img_hq, self.mean, self.std, inplace=True)
            normalize(img_lq, self.mean, self.std, inplace=True)

        return {'lq': img_lq, 'hq': img_hq, 'lq_path': lq_path}

    def __len__(self):
        return len(self.lq_paths)