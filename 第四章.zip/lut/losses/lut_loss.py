from torch import nn as nn
from torch.nn import functional as F
import torch
from basicsr.utils.registry import LOSS_REGISTRY


@LOSS_REGISTRY.register()
class NormLoss(nn.Module):
    """Example Loss.

    Args:
        loss_weight (float): Loss weight for Example loss. Default: 1.0.
    """

    def __init__(self, loss_weight=1.0):
        super(NormLoss, self).__init__()
        self.loss_weight = loss_weight

    def forward(self, pred):
        return torch.mean(pred ** 2) * self.loss_weight


@LOSS_REGISTRY.register()
class TV_3D(nn.Module):
    def __init__(self, loss_weight_tv, loss_weight_mn, dim=33):
        super(TV_3D,self).__init__()
        self.relu = torch.nn.ReLU()
        self.weight_r = torch.ones(3,dim,dim,dim-1, dtype=torch.float).cuda()
        self.weight_r[:,:,:,(0,dim-2)] *= 2.0
        self.weight_g = torch.ones(3,dim,dim-1,dim, dtype=torch.float).cuda()
        self.weight_g[:,:,(0,dim-2),:] *= 2.0
        self.weight_b = torch.ones(3,dim-1,dim,dim, dtype=torch.float).cuda()
        self.weight_b[:,(0,dim-2),:,:] *= 2.0
        self.loss_weight_tv = loss_weight_tv
        self.loss_weight_mn = loss_weight_mn

    def forward(self, LUT_list):
        tv = 0
        mn = 0
        for LUT in LUT_list:
            dif_r = LUT.LUT[:,:,:,:-1] - LUT.LUT[:,:,:,1:]
            dif_g = LUT.LUT[:,:,:-1,:] - LUT.LUT[:,:,1:,:]
            dif_b = LUT.LUT[:,:-1,:,:] - LUT.LUT[:,1:,:,:]
            tv += torch.mean(torch.mul((dif_r ** 2),self.weight_r)) + torch.mean(torch.mul((dif_g ** 2),self.weight_g)) + torch.mean(torch.mul((dif_b ** 2),self.weight_b))

            mn += torch.mean(self.relu(dif_r)) + torch.mean(self.relu(dif_g)) + torch.mean(self.relu(dif_b))

        return tv * self.loss_weight_tv, mn * self.loss_weight_mn